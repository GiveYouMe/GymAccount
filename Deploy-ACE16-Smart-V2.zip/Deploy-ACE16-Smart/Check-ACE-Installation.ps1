# Check ACE Installation Status
# This script checks if Microsoft Access Database Engine is properly installed

param(
    [string]$LogFile = "ACE16Check.log"
)

# Function to write to log
function Write-Log {
    param([string]$Message, [string]$Level = "INFO")
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $logMessage = "[$timestamp] [$Level] $Message"
    Write-Host $logMessage
    Add-Content -Path $LogFile -Value $logMessage
}

Write-Log "=== ACE Installation Check Started ==="

# Check for ACE providers in registry - separate 32-bit and 64-bit paths
Write-Log "Checking ACE registry entries..."
$aceRegistryPaths64 = @(
    "HKLM:\SOFTWARE\Microsoft\Office\16.0\Access Connectivity Engine\Engines\ACE",
    "HKLM:\SOFTWARE\Microsoft\Office\15.0\Access Connectivity Engine\Engines\ACE",
    "HKLM:\SOFTWARE\Microsoft\Office\14.0\Access Connectivity Engine\Engines\ACE"
)

$aceRegistryPaths32 = @(
    "HKLM:\SOFTWARE\WOW6432Node\Microsoft\Office\16.0\Access Connectivity Engine\Engines\ACE",
    "HKLM:\SOFTWARE\WOW6432Node\Microsoft\Office\15.0\Access Connectivity Engine\Engines\ACE",
    "HKLM:\SOFTWARE\WOW6432Node\Microsoft\Office\14.0\Access Connectivity Engine\Engines\ACE"
)

$aceArchitecture = ""
$aceFound = $false

# Check for 64-bit ACE
foreach ($regPath in $aceRegistryPaths64) {
    try {
        $aceProviders = Get-ItemProperty $regPath -ErrorAction SilentlyContinue
        if ($aceProviders) {
            Write-Log "Found 64-bit ACE installation in registry: $regPath"
            $aceArchitecture = "x64"
            $aceFound = $true
            break
        }
    }
    catch {
        # Registry path doesn't exist, continue
    }
}

# Check for 32-bit ACE if 64-bit not found
if (-not $aceArchitecture) {
    foreach ($regPath in $aceRegistryPaths32) {
        try {
            $aceProviders = Get-ItemProperty $regPath -ErrorAction SilentlyContinue
            if ($aceProviders) {
                Write-Log "Found 32-bit ACE installation in registry: $regPath"
                $aceArchitecture = "x86"
                $aceFound = $true
                break
            }
        }
        catch {
            # Registry path doesn't exist, continue
        }
    }
}

# Check for ACE files in system - separate 32-bit and 64-bit paths
Write-Log "Checking ACE files..."
$acePaths64 = @(
    "$env:ProgramFiles\Common Files\Microsoft Shared\OFFICE16\ACEOLEDB.DLL",
    "$env:ProgramFiles\Common Files\Microsoft Shared\OFFICE15\ACEOLEDB.DLL",
    "$env:ProgramFiles\Common Files\Microsoft Shared\OFFICE14\ACEOLEDB.DLL"
)

$acePaths32 = @(
    "${env:ProgramFiles(x86)}\Common Files\Microsoft Shared\OFFICE16\ACEOLEDB.DLL",
    "${env:ProgramFiles(x86)}\Common Files\Microsoft Shared\OFFICE15\ACEOLEDB.DLL",
    "${env:ProgramFiles(x86)}\Common Files\Microsoft Shared\OFFICE14\ACEOLEDB.DLL"
)

$aceFilesFound = @()

# Check for 64-bit ACE files if not found in registry
if (-not $aceArchitecture) {
    foreach ($acePath in $acePaths64) {
        if (Test-Path $acePath) {
            Write-Log "Found 64-bit ACE file: $acePath"
            $aceArchitecture = "x64"
            $aceFilesFound += $acePath
        }
    }
}

# Check for 32-bit ACE files if not found yet
if (-not $aceArchitecture) {
    foreach ($acePath in $acePaths32) {
        if (Test-Path $acePath) {
            Write-Log "Found 32-bit ACE file: $acePath"
            $aceArchitecture = "x86"
            $aceFilesFound += $acePath
        }
    }
}

# Summary
Write-Host "`n=== ACE Installation Summary ===" -ForegroundColor Cyan
if ($aceArchitecture) {
    Write-Host "✅ ACE $aceArchitecture found" -ForegroundColor Green
    Write-Host "   Architecture: $aceArchitecture" -ForegroundColor White
} else {
    Write-Host "❌ No ACE installation found" -ForegroundColor Red
}

if ($aceFilesFound.Count -gt 0) {
    Write-Host "✅ ACE files found: $($aceFilesFound.Count)" -ForegroundColor Green
    foreach ($file in $aceFilesFound) {
        Write-Host "   - $file" -ForegroundColor White
    }
} else {
    Write-Host "❌ No ACE files found" -ForegroundColor Red
}

if ($aceArchitecture) {
    Write-Host "`n✅ ACE $aceArchitecture appears to be installed and should work with your application." -ForegroundColor Green
    Write-Host "If you're still having issues, try restarting your computer." -ForegroundColor Yellow
} else {
    Write-Host "`n❌ ACE is not installed or not properly configured." -ForegroundColor Red
    Write-Host "Please download and install Microsoft Access Database Engine 2016." -ForegroundColor Yellow
    Write-Host "`nManual download options:" -ForegroundColor Yellow
    Write-Host "1. Visit: https://www.microsoft.com/en-us/download/details.aspx?id=54920" -ForegroundColor White
    Write-Host "2. Search for 'Microsoft Access Database Engine 2016' on Microsoft Download Center" -ForegroundColor White
}

Write-Log "=== ACE Installation Check Completed ===" 