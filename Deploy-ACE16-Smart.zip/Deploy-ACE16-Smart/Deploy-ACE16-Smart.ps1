# Smart ACE 16 Deployment Script
# Automatically detects application architecture and installs appropriate ACE version
# Designed for non-technical users in missionary organizations

param(
    [switch]$Force,
    [switch]$Restart,
    [switch]$Prefer64Bit,
    [string]$LogFile = "ACE16SmartDeployment.log",
    [string]$AppPath = ""
)

# Function to write to log
function Write-Log {
    param([string]$Message, [string]$Level = "INFO")
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $logMessage = "[$timestamp] [$Level] $Message"
    Write-Host $logMessage
    Add-Content -Path $LogFile -Value $logMessage
}

# Function to check if running as administrator
function Test-Administrator {
    $currentUser = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($currentUser)
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

# Function to test internet connectivity
function Test-InternetConnection {
    try {
        $response = Invoke-WebRequest -Uri "https://www.microsoft.com" -UseBasicParsing -TimeoutSec 10
        return $response.StatusCode -eq 200
    }
    catch {
        Write-Log "Internet connectivity test failed: $($_.Exception.Message)" -Level "WARNING"
        return $false
    }
}

# Function to detect application architecture
function Get-ApplicationArchitecture {
    param([string]$AppPath)
    
    Write-Log "Detecting application architecture..."
    
    # Check if AppPath is null, empty, or whitespace
    if ([string]::IsNullOrWhiteSpace($AppPath)) {
        Write-Log "No application path provided, defaulting to 32-bit for maximum compatibility" -Level "WARNING"
        return "x86"
    }
    
    if (-not (Test-Path $AppPath)) {
        Write-Log "Application not found at: $AppPath" -Level "ERROR"
        Write-Log "Defaulting to 32-bit for maximum compatibility" -Level "WARNING"
        return "x86"
    }
    
    try {
        # Method 1: Try dumpbin first (most reliable)
        $dumpbinPath = Get-Command dumpbin.exe -ErrorAction SilentlyContinue
        if ($dumpbinPath) {
            Write-Log "Using dumpbin.exe for architecture detection..."
            $dumpbinOutput = & dumpbin.exe /headers $AppPath 2>$null
            if ($LASTEXITCODE -eq 0) {
                if ($dumpbinOutput -match "x64") {
                    Write-Log "Application is 64-bit (x64) - detected by dumpbin"
                    return "x64"
                } elseif ($dumpbinOutput -match "x86") {
                    Write-Log "Application is 32-bit (x86) - detected by dumpbin"
                    return "x86"
                }
            }
        } else {
            Write-Log "dumpbin.exe not found, using alternative detection methods..." -Level "WARNING"
        }
        
        # Method 2: Check PE header directly
        Write-Log "Analyzing PE header for architecture detection..."
        $fileInfo = Get-Item $AppPath
        $peHeader = [System.IO.File]::ReadAllBytes($AppPath)
        
        # Check PE header for architecture
        if ($peHeader.Length -gt 60) {
            $machineOffset = [System.BitConverter]::ToUInt16($peHeader, 60)
            if ($peHeader.Length -gt ($machineOffset + 4)) {
                $machine = [System.BitConverter]::ToUInt16($peHeader, $machineOffset + 4)
                switch ($machine) {
                    0x014c { 
                        Write-Log "Application is 32-bit (x86) - detected from PE header"
                        return "x86"
                    }
                    0x8664 { 
                        Write-Log "Application is 64-bit (x64) - detected from PE header"
                        return "x64"
                    }
                }
            }
        }
        
        # Method 3: Check file size as last resort
        Write-Log "Using file size analysis as fallback..." -Level "WARNING"
        $fileSize = $fileInfo.Length
        if ($fileSize -gt 10MB) {
            Write-Log "Large file size suggests 64-bit application, defaulting to x64" -Level "WARNING"
            return "x64"
        } else {
            Write-Log "Smaller file size suggests 32-bit application, defaulting to x86" -Level "WARNING"
            return "x86"
        }
    }
    catch {
        Write-Log "Error detecting architecture: $($_.Exception.Message)" -Level "ERROR"
        Write-Log "Defaulting to 32-bit for maximum compatibility" -Level "WARNING"
        return "x86"
    }
}

# Function to check existing Office/ACE installation
function Get-ExistingOfficeInfo {
    Write-Log "Checking existing Office/ACE installations..."
    
    $officeInfo = @{
        "Office32Bit" = $false
        "Office64Bit" = $false
        "ACE32Bit" = $false
        "ACE64Bit" = $false
        "OfficeVersion" = ""
        "Recommendation" = ""
    }
    
    # Check for 32-bit Office installations
    $office32Paths = @(
        "${env:ProgramFiles(x86)}\Microsoft Office",
        "${env:ProgramFiles(x86)}\Microsoft Office\Office16",
        "${env:ProgramFiles(x86)}\Microsoft Office\Office15",
        "${env:ProgramFiles(x86)}\Microsoft Office\Office14"
    )
    
    foreach ($path in $office32Paths) {
        if (Test-Path $path) {
            $officeInfo["Office32Bit"] = $true
            Write-Log "Found 32-bit Office installation at: $path"
            
            # Try to detect Office version
            $excelPath = Join-Path $path "EXCEL.EXE"
            if (Test-Path $excelPath) {
                try {
                    $versionInfo = [System.Diagnostics.FileVersionInfo]::GetVersionInfo($excelPath)
                    $officeInfo["OfficeVersion"] = $versionInfo.FileVersion
                    Write-Log "Office version detected: $($versionInfo.FileVersion)"
                }
                catch {
                    Write-Log "Could not detect Office version" -Level "WARNING"
                }
            }
            break
        }
    }
    
    # Check for 64-bit Office installations
    $office64Paths = @(
        "$env:ProgramFiles\Microsoft Office",
        "$env:ProgramFiles\Microsoft Office\Office16",
        "$env:ProgramFiles\Microsoft Office\Office15",
        "$env:ProgramFiles\Microsoft Office\Office14"
    )
    
    foreach ($path in $office64Paths) {
        if (Test-Path $path) {
            $officeInfo["Office64Bit"] = $true
            Write-Log "Found 64-bit Office installation at: $path"
            break
        }
    }
    
    # Check for ACE providers in registry
    $aceRegistryPaths = @(
        "HKLM:\SOFTWARE\Microsoft\Office\16.0\Access Connectivity Engine\Engines\ACE",
        "HKLM:\SOFTWARE\Microsoft\Office\15.0\Access Connectivity Engine\Engines\ACE",
        "HKLM:\SOFTWARE\Microsoft\Office\14.0\Access Connectivity Engine\Engines\ACE",
        "HKLM:\SOFTWARE\WOW6432Node\Microsoft\Office\16.0\Access Connectivity Engine\Engines\ACE",
        "HKLM:\SOFTWARE\WOW6432Node\Microsoft\Office\15.0\Access Connectivity Engine\Engines\ACE",
        "HKLM:\SOFTWARE\WOW6432Node\Microsoft\Office\14.0\Access Connectivity Engine\Engines\ACE"
    )
    
    foreach ($regPath in $aceRegistryPaths) {
        try {
            $aceProviders = Get-ItemProperty $regPath -ErrorAction SilentlyContinue
            if ($aceProviders) {
                if ($regPath -match "WOW6432Node") {
                    $officeInfo["ACE64Bit"] = $true
                    Write-Log "Found 64-bit ACE installation in registry: $regPath"
                } else {
                    $officeInfo["ACE32Bit"] = $true
                    Write-Log "Found 32-bit ACE installation in registry: $regPath"
                }
            }
        }
        catch {
            # Registry path doesn't exist, continue
        }
    }
    
    # Check for ACE files in system
    $acePaths = @(
        "${env:ProgramFiles(x86)}\Common Files\Microsoft Shared\OFFICE16\ACEOLEDB.DLL",
        "${env:ProgramFiles(x86)}\Common Files\Microsoft Shared\OFFICE15\ACEOLEDB.DLL",
        "${env:ProgramFiles(x86)}\Common Files\Microsoft Shared\OFFICE14\ACEOLEDB.DLL",
        "$env:ProgramFiles\Common Files\Microsoft Shared\OFFICE16\ACEOLEDB.DLL",
        "$env:ProgramFiles\Common Files\Microsoft Shared\OFFICE15\ACEOLEDB.DLL",
        "$env:ProgramFiles\Common Files\Microsoft Shared\OFFICE14\ACEOLEDB.DLL"
    )
    
    foreach ($acePath in $acePaths) {
        if (Test-Path $acePath) {
            if ($acePath -match "Program Files\\") {
                $officeInfo["ACE64Bit"] = $true
                Write-Log "Found 64-bit ACE file: $acePath"
            } else {
                $officeInfo["ACE32Bit"] = $true
                Write-Log "Found 32-bit ACE file: $acePath"
            }
        }
    }
    
    return $officeInfo
}



# Function to provide installation recommendation
function Get-InstallationRecommendation {
    param(
        [string]$AppArchitecture,
        [hashtable]$OfficeInfo,
        [bool]$Prefer64Bit = $false
    )
    
    Write-Log "Analyzing installation requirements..."
    
    # If user prefers 64-bit and system supports it
    if ($Prefer64Bit -and $AppArchitecture -eq "x64") {
        if ($OfficeInfo["Office64Bit"] -or $OfficeInfo["ACE64Bit"]) {
            $recommendation = "Install 64-bit ACE 16.0 (compatible with existing 64-bit Office)"
        } else {
            $recommendation = "Install 64-bit ACE 16.0 (application requires 64-bit, Office compatibility may be affected)"
        }
        return $recommendation
    }
    
    # Normal logic based on application architecture
    if ($AppArchitecture -eq "x64") {
        if ($OfficeInfo["Office64Bit"] -or $OfficeInfo["ACE64Bit"]) {
            $recommendation = "Install 64-bit ACE 16.0 (compatible with existing 64-bit Office)"
        } else {
            $recommendation = "Install 64-bit ACE 16.0 (application requires 64-bit)"
        }
    } else {
        if ($OfficeInfo["Office32Bit"]) {
            $recommendation = "Install 32-bit ACE 16.0 (compatible with existing 32-bit Office)"
        } else {
            $recommendation = "Install 32-bit ACE 16.0 (application is 32-bit, maximum compatibility)"
        }
    }
    
    Write-Log "Recommendation: $recommendation"
    return $recommendation
}

# Function to install ACE 16.0
function Install-ACE16 {
    param([string]$Architecture)
    
    Write-Log "=== Install-ACE16 function called with architecture: $Architecture ==="
    Write-Log "Installing ACE 16.0 ($Architecture)..."
    
    $installerPath = "$env:TEMP\ACE16_$Architecture.exe"
    Write-Log "Installer path set to: $installerPath"
    
    try {
        Write-Log "Entered try block successfully"
        
        # Initialize download success flag
        $downloadSuccess = $false
        Write-Log "Download success flag initialized to: $downloadSuccess"
        
        # Check internet connectivity
        if (-not (Test-InternetConnection)) {
            Write-Log "No internet connection detected. Please check your network connection." -Level "ERROR"
            return $false
        }
        
        # Download installer with retry logic
        Write-Log "Downloading ACE 16.0 $Architecture installer..."
        Write-Host "Downloading ACE 16.0 $Architecture installer..." -ForegroundColor Yellow
        
        $webClient = New-Object System.Net.WebClient
        
        # Use the correct URLs based on architecture
        $downloadUrl = if ($Architecture -eq "x64") {
            "https://download.microsoft.com/download/3/5/c/35c84c36-661a-44e6-9324-8786b8dbe231/accessdatabaseengine_X64.exe"
        } else {
            "https://download.microsoft.com/download/3/5/c/35c84c36-661a-44e6-9324-8786b8dbe231/accessdatabaseengine.exe"
        }
        
        try {
            Write-Log "Downloading from: $downloadUrl"
            Write-Host "Downloading ACE 16.0 $Architecture..." -ForegroundColor Yellow
            Write-Host "Target: $installerPath" -ForegroundColor Yellow
            
            $webClient.DownloadFile($downloadUrl, $installerPath)
            
            Write-Log "Download completed, checking file..."
            if (Test-Path $installerPath) {
                $fileInfo = Get-Item $installerPath
                Write-Log "File downloaded successfully: $($fileInfo.Length) bytes"
                $downloadSuccess = $true
                Write-Log "Download successful from direct URL"
                Write-Host "Download successful!" -ForegroundColor Green
            } else {
                Write-Log "File not found after download attempt" -Level "ERROR"
                Write-Host "Download failed - file not found" -ForegroundColor Red
            }
        }
        catch {
            Write-Log "Direct download failed: $($_.Exception.Message)" -Level "WARNING"
            Write-Host "Direct download failed: $($_.Exception.Message)" -ForegroundColor Red
            Write-Host "Trying alternative methods..." -ForegroundColor Yellow
            
            # Try alternative download method using Invoke-WebRequest
            try {
                Write-Log "Trying alternative download method with Invoke-WebRequest..."
                Write-Host "Trying alternative download method..." -ForegroundColor Yellow
                Write-Host "URL: $downloadUrl" -ForegroundColor Yellow
                Write-Host "Target: $installerPath" -ForegroundColor Yellow
                
                Invoke-WebRequest -Uri $downloadUrl -OutFile $installerPath -UseBasicParsing -TimeoutSec 120
                
                Write-Log "Invoke-WebRequest completed, checking file..."
                if (Test-Path $installerPath) {
                    $fileInfo = Get-Item $installerPath
                    Write-Log "File downloaded successfully: $($fileInfo.Length) bytes"
                    $downloadSuccess = $true
                    Write-Log "Download successful with Invoke-WebRequest"
                    Write-Host "Download successful with alternative method!" -ForegroundColor Green
                } else {
                    Write-Log "File not found after Invoke-WebRequest" -Level "ERROR"
                    Write-Host "Alternative download failed - file not found" -ForegroundColor Red
                }
            }
            catch {
                Write-Log "Alternative download failed: $($_.Exception.Message)" -Level "WARNING"
                Write-Host "Alternative download failed: $($_.Exception.Message)" -ForegroundColor Red
            }
        }
        
        if (-not $downloadSuccess) {
            Write-Log "All download attempts failed" -Level "ERROR"
            Write-Host "All download attempts failed." -ForegroundColor Red
            Write-Host "`nManual download options:" -ForegroundColor Yellow
            Write-Host "1. 32-bit: https://download.microsoft.com/download/3/5/c/35c84c36-661a-44e6-9324-8786b8dbe231/accessdatabaseengine.exe" -ForegroundColor White
            Write-Host "2. 64-bit: https://download.microsoft.com/download/3/5/c/35c84c36-661a-44e6-9324-8786b8dbe231/accessdatabaseengine_X64.exe" -ForegroundColor White
            Write-Host "`nPlease download manually and run the installer, then restart this script." -ForegroundColor Yellow
            return $false
        }
        
        # Verify installer file size (should be several MB)
        $fileInfo = Get-Item $installerPath
        if ($fileInfo.Length -lt 1000000) { # Less than 1MB
            Write-Log "Installer file appears to be invalid (size: $($fileInfo.Length) bytes)" -Level "ERROR"
            Write-Host "Downloaded file appears to be invalid or corrupted." -ForegroundColor Red
            Remove-Item $installerPath -Force -ErrorAction SilentlyContinue
            return $false
        }
        
        Write-Log "Installer verified: $($fileInfo.Length) bytes"
        Write-Host "Installer verified successfully." -ForegroundColor Green
        
        # Install silently
        Write-Log "Installing ACE 16.0 $Architecture..."
        Write-Host "Installing ACE 16.0 $Architecture..." -ForegroundColor Yellow
        
        $process = Start-Process -FilePath $installerPath -ArgumentList "/quiet", "/norestart" -Wait -PassThru
        
        if ($process.ExitCode -eq 0) {
            Write-Log "ACE 16.0 $Architecture installed successfully"
            Write-Host "ACE 16.0 $Architecture installed successfully!" -ForegroundColor Green
            return $true
        } else {
            Write-Log "ACE 16.0 installation failed with exit code: $($process.ExitCode)" -Level "ERROR"
            Write-Host "ACE 16.0 installation failed with exit code: $($process.ExitCode)" -ForegroundColor Red
            
            # Check for common error codes
            switch ($process.ExitCode) {
                1603 { Write-Log "Error 1603: Installation failed - may need to uninstall previous version" -Level "ERROR" }
                1605 { Write-Log "Error 1605: Installation cancelled by user" -Level "ERROR" }
                3010 { Write-Log "Error 3010: Installation successful but restart required" -Level "WARNING" }
                default { Write-Log "Unknown installation error code: $($process.ExitCode)" -Level "ERROR" }
            }
            return $false
        }
    }
    catch {
        Write-Log "Error installing ACE 16.0: $($_.Exception.Message)" -Level "ERROR"
        Write-Host "Error installing ACE 16.0: $($_.Exception.Message)" -ForegroundColor Red
        return $false
    }
    finally {
        # Clean up installer
        if (Test-Path $installerPath) {
            Remove-Item $installerPath -Force -ErrorAction SilentlyContinue
        }
    }
}

# Function to provide architecture guidance
function Show-ArchitectureGuidance {
    param(
        [string]$AppArchitecture,
        [hashtable]$OfficeInfo
    )
    
    Write-Host "`n=== Architecture Guidance ===" -ForegroundColor Cyan
    
    if ($AppArchitecture -eq "x64") {
        Write-Host "Your application is 64-bit." -ForegroundColor Yellow
        Write-Host "Benefits: Better performance, modern architecture" -ForegroundColor Green
        Write-Host "Requirements: 64-bit ACE 16.0 database engine" -ForegroundColor Yellow
        
        if ($OfficeInfo["Office32Bit"]) {
            Write-Host "`n⚠️  NOTE: You have 32-bit Office installed" -ForegroundColor Red
            Write-Host "   - 64-bit application can work with 32-bit Office" -ForegroundColor Yellow
            Write-Host "   - Only the database engine needs to be 64-bit" -ForegroundColor Yellow
            Write-Host "   - Your Office applications will continue to work normally" -ForegroundColor Green
        }
        
        if ($OfficeInfo["Office64Bit"]) {
            Write-Host "`n✅ Perfect compatibility with your 64-bit Office installation" -ForegroundColor Green
        }
    } else {
        Write-Host "Your application is 32-bit." -ForegroundColor Yellow
        Write-Host "Benefits: Maximum compatibility with existing Office installations" -ForegroundColor Green
        Write-Host "Requirements: 32-bit ACE 16.0 database engine" -ForegroundColor Yellow
        
        if ($OfficeInfo["Office32Bit"]) {
            Write-Host "`n✅ Perfect compatibility with your 32-bit Office installation" -ForegroundColor Green
        }
        
        if ($OfficeInfo["Office64Bit"]) {
            Write-Host "`n⚠️  NOTE: You have 64-bit Office installed" -ForegroundColor Yellow
            Write-Host "   - 32-bit application will work with 64-bit Office" -ForegroundColor Green
            Write-Host "   - 32-bit database engine will be installed" -ForegroundColor Yellow
        }
    }
    
    Write-Host "`nThis script will install the appropriate database engine without affecting your Office installation." -ForegroundColor Green
}

# Main execution
Write-Log "=== Smart ACE 16 Deployment Started ==="

# Check administrator rights
if (-not (Test-Administrator)) {
    Write-Log "This script requires administrator privileges for full functionality. Some features may not work." -Level "WARNING"
    Write-Host "WARNING: This script requires administrator privileges for full functionality." -ForegroundColor Yellow
    Write-Host "Some features may not work without administrator privileges." -ForegroundColor Yellow
    Write-Host "You can continue, but installation may fail." -ForegroundColor Yellow
    Write-Host "To run with full privileges, right-click and select 'Run as Administrator'" -ForegroundColor Yellow
}

# Detect application architecture
$appArchitecture = Get-ApplicationArchitecture -AppPath $AppPath
if (-not $appArchitecture) {
    Write-Log "Could not detect application architecture. Defaulting to 32-bit for maximum compatibility." -Level "WARNING"
    Write-Host "WARNING: Could not detect application architecture." -ForegroundColor Yellow
    Write-Host "Defaulting to 32-bit for maximum compatibility." -ForegroundColor Yellow
    $appArchitecture = "x86"
}

# Check existing Office/ACE installations
$officeInfo = Get-ExistingOfficeInfo

# Get installation recommendation
$recommendation = Get-InstallationRecommendation -AppArchitecture $appArchitecture -OfficeInfo $officeInfo -Prefer64Bit $Prefer64Bit

# Display summary
Write-Log "=== Installation Summary ==="
Write-Log "Application Architecture: $appArchitecture"
Write-Log "32-bit Office: $($officeInfo['Office32Bit'])"
Write-Log "64-bit Office: $($officeInfo['Office64Bit'])"
Write-Log "32-bit ACE: $($officeInfo['ACE32Bit'])"
Write-Log "64-bit ACE: $($officeInfo['ACE64Bit'])"
Write-Log "Office Version: $($officeInfo['OfficeVersion'])"
Write-Log "Recommendation: $recommendation"

# Show architecture guidance
Show-ArchitectureGuidance -AppArchitecture $appArchitecture -OfficeInfo $officeInfo

# Confirm installation
if (-not $Force) {
    Write-Host "`nInstallation Summary:" -ForegroundColor Cyan
    Write-Host "Application: $appArchitecture"
    Write-Host "Recommendation: $recommendation"
    Write-Host "`nDo you want to proceed with the installation? (Y/N)"
    $response = Read-Host
    if ($response -notmatch "^[Yy]") {
        Write-Log "Installation cancelled by user"
        Write-Host "Installation cancelled." -ForegroundColor Yellow
        exit 0
    }
}

# Check if ACE is already installed with matching architecture
Write-Log "Checking if ACE is already installed with matching architecture..."
$aceAlreadyInstalled = $false
$aceArchitecture = ""

# Check for ACE providers in registry - separate 32-bit and 64-bit paths
$aceRegistryPaths64 = @(
    "HKLM:\SOFTWARE\Microsoft\Office\16.0\Access Connectivity Engine\Engines\ACE",
    "HKLM:\SOFTWARE\Microsoft\Office\15.0\Access Connectivity Engine\Engines\ACE",
    "HKLM:\SOFTWARE\Microsoft\Office\14.0\Access Connectivity Engine\Engines\ACE"
)

$aceRegistryPaths32 = @(
    "HKLM:\SOFTWARE\WOW6432Node\Microsoft\Office\16.0\Access Connectivity Engine\Engines\ACE",
    "HKLM:\SOFTWARE\WOW6432Node\Microsoft\Office\15.0\Access Connectivity Engine\Engines\ACE",
    "HKLM:\SOFTWARE\WOW6432Node\Microsoft\Office\14.0\Access Connectivity Engine\Engines\ACE"
)

# Check for 64-bit ACE
foreach ($regPath in $aceRegistryPaths64) {
    try {
        $aceProviders = Get-ItemProperty $regPath -ErrorAction SilentlyContinue
        if ($aceProviders) {
            Write-Log "Found existing 64-bit ACE installation in registry: $regPath"
            $aceArchitecture = "x64"
            break
        }
    }
    catch {
        # Registry path doesn't exist, continue
    }
}

# Check for 32-bit ACE if 64-bit not found
if (-not $aceArchitecture) {
    foreach ($regPath in $aceRegistryPaths32) {
        try {
            $aceProviders = Get-ItemProperty $regPath -ErrorAction SilentlyContinue
            if ($aceProviders) {
                Write-Log "Found existing 32-bit ACE installation in registry: $regPath"
                $aceArchitecture = "x86"
                break
            }
        }
        catch {
            # Registry path doesn't exist, continue
        }
    }
}

# Check for ACE files in system - separate 32-bit and 64-bit paths
$acePaths64 = @(
    "$env:ProgramFiles\Common Files\Microsoft Shared\OFFICE16\ACEOLEDB.DLL",
    "$env:ProgramFiles\Common Files\Microsoft Shared\OFFICE15\ACEOLEDB.DLL",
    "$env:ProgramFiles\Common Files\Microsoft Shared\OFFICE14\ACEOLEDB.DLL"
)

$acePaths32 = @(
    "${env:ProgramFiles(x86)}\Common Files\Microsoft Shared\OFFICE16\ACEOLEDB.DLL",
    "${env:ProgramFiles(x86)}\Common Files\Microsoft Shared\OFFICE15\ACEOLEDB.DLL",
    "${env:ProgramFiles(x86)}\Common Files\Microsoft Shared\OFFICE14\ACEOLEDB.DLL"
)

# Check for 64-bit ACE files if not found in registry
if (-not $aceArchitecture) {
    foreach ($acePath in $acePaths64) {
        if (Test-Path $acePath) {
            Write-Log "Found existing 64-bit ACE file: $acePath"
            $aceArchitecture = "x64"
            break
        }
    }
}

# Check for 32-bit ACE files if not found yet
if (-not $aceArchitecture) {
    foreach ($acePath in $acePaths32) {
        if (Test-Path $acePath) {
            Write-Log "Found existing 32-bit ACE file: $acePath"
            $aceArchitecture = "x86"
            break
        }
    }
}

# Determine if we need to install ACE
if ($aceArchitecture) {
    Write-Log "Found ACE $aceArchitecture installation"
    
    # Check if architecture matches application needs
    if ($aceArchitecture -eq $appArchitecture) {
        Write-Log "ACE architecture ($aceArchitecture) matches application architecture ($appArchitecture) - no installation needed"
        Write-Host "`n✅ ACE $aceArchitecture is already installed and matches your $appArchitecture application!" -ForegroundColor Green
        Write-Host "No additional installation needed." -ForegroundColor Green
        $aceAlreadyInstalled = $true
        $success = $true
    } else {
        Write-Log "ACE architecture ($aceArchitecture) does not match application architecture ($appArchitecture) - checking if existing installation works"
        Write-Host "`n⚠️  Found ACE $aceArchitecture but your application is $appArchitecture" -ForegroundColor Yellow
        
        # Test if the existing ACE installation works despite architecture mismatch
        Write-Host "Testing if existing ACE installation works..." -ForegroundColor Yellow
        try {
            # Try to create a simple test connection
            $testConnection = New-Object System.Data.OleDb.OleDbConnection
            $testConnection.ConnectionString = "Provider=Microsoft.ACE.OLEDB.16.0;Data Source=$env:TEMP\test.accdb;"
            $testConnection.Open()
            $testConnection.Close()
            $testConnection.Dispose()
            
            Write-Log "Existing ACE installation works despite architecture mismatch"
            Write-Host "✅ Existing ACE installation works! No additional installation needed." -ForegroundColor Green
            $aceAlreadyInstalled = $true
            $success = $true
        }
        catch {
            Write-Log "Existing ACE installation does not work - installation needed"
            Write-Host "Installing the correct ACE version..." -ForegroundColor Yellow
            $aceAlreadyInstalled = $false
        }
    }
} else {
    Write-Log "No ACE installation found - proceeding with installation"
    $aceAlreadyInstalled = $false
}

if (-not $aceAlreadyInstalled) {
    Write-Log "ACE installation needed - proceeding with installation"
    # Install ACE 16.0
    $targetArchitecture = if ($appArchitecture -eq "x64") { "x64" } else { "x86" }
    $success = Install-ACE16 -Architecture $targetArchitecture
}

if ($success) {
    Write-Log "=== Installation Completed Successfully ==="
    Write-Host "`n✅ Installation completed successfully!" -ForegroundColor Green
    Write-Host "Application: $appArchitecture"
    Write-Host "ACE 16.0: $targetArchitecture"
    Write-Host "`nYou can now run your application." -ForegroundColor Green
    
    if ($Restart) {
        Write-Log "Restarting computer as requested..."
        Write-Host "`nRestarting computer..." -ForegroundColor Yellow
        Restart-Computer -Force
    } else {
        Write-Host "`nNote: You may need to restart your computer for changes to take effect." -ForegroundColor Yellow
    }
} else {
    Write-Log "=== Installation Failed ===" -Level "ERROR"
    Write-Host "`n❌ Installation failed. Please check the log file: $LogFile" -ForegroundColor Red
    Write-Host "`nTroubleshooting tips:" -ForegroundColor Yellow
    Write-Host "1. Check your internet connection" -ForegroundColor White
    Write-Host "2. Ensure you have administrator privileges" -ForegroundColor White
    Write-Host "3. Try running the script again" -ForegroundColor White
    Write-Host "4. Manual installation option:" -ForegroundColor White
    Write-Host "   - 32-bit: https://download.microsoft.com/download/3/5/c/35c84c36-661a-44e6-9324-8786b8dbe231/accessdatabaseengine.exe" -ForegroundColor White
    Write-Host "   - 64-bit: https://download.microsoft.com/download/3/5/c/35c84c36-661a-44e6-9324-8786b8dbe231/accessdatabaseengine_X64.exe" -ForegroundColor White
    Write-Host "   - Run the installer manually" -ForegroundColor White
    Write-Host "5. Contact support if the problem persists" -ForegroundColor White
    Write-Host "`nScript completed with errors. Check the log file for details." -ForegroundColor Yellow
} 