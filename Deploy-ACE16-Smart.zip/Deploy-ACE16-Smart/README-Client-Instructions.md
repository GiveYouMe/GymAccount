# GymAccount.NET - ACE 16 Deployment Tool

## 🚀 Quick Start

**Just run the main script and follow the prompts!**

### Step 1: Choose Your GymAccount Version

Choose your GymAccount version:

🔄 **32-bit Version (GymAccount-x86.msi)**
   ✅ Maximum compatibility
   ✅ Works on all systems
   ✅ Recommended for most users

🔄 **64-bit Version (GymAccount-x64.msi)**  
   ✅ Better performance
   ✅ Modern architecture
   ✅ Requires 64-bit Windows

**Note:** You can install 64-bit GymAccount even if you have 32-bit Office - they work together perfectly!

### Step 2: Install GymAccount (Recommended)
Install your chosen GymAccount version first, then run the deployment script.

**Alternative:** You can run the script before installing GymAccount - it will install a compatible database engine.

### Step 3: Run the Script
1. **Right-click** on `Deploy-ACE16-Smart.bat`
2. **Select "Run as administrator"**
3. **Click "Yes"** when prompted

### Step 4: Follow the Prompts
- Choose **option 1** for architecture (Auto-detect)
- Choose **option 1** for restart (Ask before restart)
- Type **Y** when asked to proceed

### Step 5: Wait for Completion
- The script will automatically detect your system
- It will install the correct ACE version if needed
- **Don't close the window** during installation

## ✅ Success Indicators

When successful, you'll see:
- ✅ "ACE is already installed and should work with your application!"
- ✅ "Installation completed successfully!"
- ✅ "Your application should now work with the database"

## 📁 Files Included

- **`Deploy-ACE16-Smart.bat`** - **MAIN SCRIPT** (run this)
- **`Deploy-ACE16-Smart.ps1`** - Required (don't delete)
- **`Check-ACE-Installation.ps1`** - Optional diagnostic tool
- **`README-Client-Instructions.md`** - This file

## 🔧 Troubleshooting

### If the script closes immediately:
- Make sure you're running as administrator
- Check that all files are in the same folder

### If download fails:
- Check your internet connection
- The script will provide manual download links

### If installation fails:
- Ensure you have administrator privileges
- Restart your computer and try again

## 📞 Support

If you have issues:
1. Check the log file: `ACE16SmartDeployment.log`
2. Run `Check-ACE-Installation.ps1` for diagnostics
3. Contact your IT support

---

**That's it! The script handles everything automatically.** 🎯 