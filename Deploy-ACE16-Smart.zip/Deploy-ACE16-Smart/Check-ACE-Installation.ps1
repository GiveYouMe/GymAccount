# Check ACE Installation Status
# This script checks if Microsoft Access Database Engine is properly installed

param(
    [string]$LogFile = "ACE16Check.log"
)

# Function to write to log
function Write-Log {
    param([string]$Message, [string]$Level = "INFO")
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $logMessage = "[$timestamp] [$Level] $Message"
    Write-Host $logMessage
    Add-Content -Path $LogFile -Value $logMessage
}

Write-Log "=== ACE Installation Check Started ==="

# Check for ACE providers in registry
Write-Log "Checking ACE registry entries..."
$aceRegistryPaths = @(
    "HKLM:\SOFTWARE\Microsoft\Office\16.0\Access Connectivity Engine\Engines\ACE",
    "HKLM:\SOFTWARE\Microsoft\Office\15.0\Access Connectivity Engine\Engines\ACE",
    "HKLM:\SOFTWARE\Microsoft\Office\14.0\Access Connectivity Engine\Engines\ACE",
    "HKLM:\SOFTWARE\WOW6432Node\Microsoft\Office\16.0\Access Connectivity Engine\Engines\ACE",
    "HKLM:\SOFTWARE\WOW6432Node\Microsoft\Office\15.0\Access Connectivity Engine\Engines\ACE",
    "HKLM:\SOFTWARE\WOW6432Node\Microsoft\Office\14.0\Access Connectivity Engine\Engines\ACE"
)

$aceFound = $false
foreach ($regPath in $aceRegistryPaths) {
    try {
        $aceProviders = Get-ItemProperty $regPath -ErrorAction SilentlyContinue
        if ($aceProviders) {
            Write-Log "Found ACE installation in registry: $regPath"
            $aceFound = $true
        }
    }
    catch {
        # Registry path doesn't exist, continue
    }
}

# Check for ACE files in system
Write-Log "Checking ACE files..."
$acePaths = @(
    "${env:ProgramFiles(x86)}\Common Files\Microsoft Shared\OFFICE16\ACEOLEDB.DLL",
    "${env:ProgramFiles(x86)}\Common Files\Microsoft Shared\OFFICE15\ACEOLEDB.DLL",
    "${env:ProgramFiles(x86)}\Common Files\Microsoft Shared\OFFICE14\ACEOLEDB.DLL",
    "$env:ProgramFiles\Common Files\Microsoft Shared\OFFICE16\ACEOLEDB.DLL",
    "$env:ProgramFiles\Common Files\Microsoft Shared\OFFICE15\ACEOLEDB.DLL",
    "$env:ProgramFiles\Common Files\Microsoft Shared\OFFICE14\ACEOLEDB.DLL"
)

$aceFilesFound = @()
foreach ($acePath in $acePaths) {
    if (Test-Path $acePath) {
        Write-Log "Found ACE file: $acePath"
        $aceFilesFound += $acePath
    }
}

# Summary
Write-Host "`n=== ACE Installation Summary ===" -ForegroundColor Cyan
if ($aceFound) {
    Write-Host "✅ ACE registry entries found" -ForegroundColor Green
} else {
    Write-Host "❌ No ACE registry entries found" -ForegroundColor Red
}

if ($aceFilesFound.Count -gt 0) {
    Write-Host "✅ ACE files found: $($aceFilesFound.Count)" -ForegroundColor Green
    foreach ($file in $aceFilesFound) {
        Write-Host "   - $file" -ForegroundColor White
    }
} else {
    Write-Host "❌ No ACE files found" -ForegroundColor Red
}

if ($aceFound -or $aceFilesFound.Count -gt 0) {
    Write-Host "`n✅ ACE appears to be installed and should work with your application." -ForegroundColor Green
    Write-Host "If you're still having issues, try restarting your computer." -ForegroundColor Yellow
} else {
    Write-Host "`n❌ ACE is not installed or not properly configured." -ForegroundColor Red
    Write-Host "Please download and install Microsoft Access Database Engine 2016." -ForegroundColor Yellow
    Write-Host "`nManual download options:" -ForegroundColor Yellow
    Write-Host "1. Visit: https://www.microsoft.com/en-us/download/details.aspx?id=54920" -ForegroundColor White
    Write-Host "2. Search for 'Microsoft Access Database Engine 2016' on Microsoft Download Center" -ForegroundColor White
}

Write-Log "=== ACE Installation Check Completed ===" 