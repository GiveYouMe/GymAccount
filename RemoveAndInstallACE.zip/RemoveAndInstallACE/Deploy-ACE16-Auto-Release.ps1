# Automated ACE 16 Deployment Script for Client Systems
# This script removes all Office components and installs Microsoft Access Database Engine 2016
# Designed for automated client deployment with comprehensive logging and error handling
# Run as Administrator

param(
    [switch]$Force,
    [switch]$Restart,
    [switch]$SkipOfficeRemoval,
    [switch]$SkipACEInstall,
    [string]$LogFile = "ACE16Deployment.log",
    [string]$Architecture = "x64"  # x64 or x86
)

# Function to write to log
function Write-Log {
    param([string]$Message, [string]$Level = "INFO")
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $logMessage = "[$timestamp] [$Level] $Message"
    Write-Host $logMessage
    Add-Content -Path $LogFile -Value $logMessage
}

# Function to check if running as administrator
function Test-Administrator {
    $currentUser = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($currentUser)
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

# Function to check system requirements
function Test-SystemRequirements {
    Write-Log "Checking system requirements..."
    
    $requirements = @{
        "Windows Version" = $false
        "Architecture" = $false
        "Administrator Rights" = $false
        "Internet Connection" = $false
    }
    
    # Check Windows version (Windows 7 SP1 or later)
    $os = Get-WmiObject -Class Win32_OperatingSystem
    $windowsVersion = [System.Version]$os.Version
    
    # Windows 7 SP1 = 6.1, Windows 8 = 6.2, Windows 8.1 = 6.3, Windows 10 = 10.0, Windows 11 = 10.0
    if ($windowsVersion.Major -ge 6) {
        $requirements["Windows Version"] = $true
        Write-Log "Windows version: $($os.Caption) $($os.Version)"
    } else {
        Write-Log "Windows version not supported: $($os.Caption) $($os.Version)" -Level "ERROR"
    }
    
    # Check architecture
    $systemArchitecture = $env:PROCESSOR_ARCHITECTURE
    if ($Architecture -eq "x64" -and $systemArchitecture -eq "AMD64") {
        $requirements["Architecture"] = $true
        Write-Log "System architecture: $systemArchitecture (64-bit)"
    } elseif ($Architecture -eq "x86" -and $systemArchitecture -eq "x86") {
        $requirements["Architecture"] = $true
        Write-Log "System architecture: $systemArchitecture (32-bit)"
    } else {
        Write-Log "Architecture mismatch: Expected $Architecture, found $systemArchitecture" -Level "ERROR"
    }
    
    # Check administrator rights
    if (Test-Administrator) {
        $requirements["Administrator Rights"] = $true
        Write-Log "Running with administrator privileges"
    } else {
        Write-Log "Not running with administrator privileges" -Level "ERROR"
    }
    
    # Check internet connection
    try {
        $response = Invoke-WebRequest -Uri "https://www.microsoft.com" -UseBasicParsing -TimeoutSec 10
        if ($response.StatusCode -eq 200) {
            $requirements["Internet Connection"] = $true
            Write-Log "Internet connection available"
        }
    }
    catch {
        Write-Log "Internet connection not available: $($_.Exception.Message)" -Level "ERROR"
    }
    
    $failedRequirements = $requirements.Values | Where-Object { $_ -eq $false }
    if ($failedRequirements.Count -eq 0) {
        Write-Log "All system requirements met"
        return $true
    } else {
        Write-Log "System requirements check failed" -Level "ERROR"
        return $false
    }
}

# Function to create system restore point
function New-SystemRestorePoint {
    Write-Log "Creating system restore point..."
    
    try {
        $restorePointName = "Before ACE 16 Deployment - $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')"
        
        # Check if System Restore is enabled
        $restoreEnabled = Get-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\SystemRestore" -Name "RPSessionInterval" -ErrorAction SilentlyContinue
        
        if ($restoreEnabled) {
            # Create restore point using PowerShell
            $restorePoint = New-Object -ComObject SystemRestore.Restore
            $restorePoint.CreateRestorePoint($restorePointName, 0, 100)
            Write-Log "System restore point created: $restorePointName"
            return $true
        } else {
            Write-Log "System Restore is not enabled on this system" -Level "WARN"
            return $false
        }
    }
    catch {
        Write-Log "Failed to create system restore point: $($_.Exception.Message)" -Level "WARN"
        return $false
    }
}

# Function to stop Office processes
function Stop-OfficeProcesses {
    Write-Log "Stopping Office processes..."
    
    $officeProcesses = @(
        "WINWORD", "EXCEL", "POWERPNT", "OUTLOOK", "MSACCESS", "ONENOTE",
        "WINPROJ", "VISIO", "LYNC", "TEAMS", "ONEDRIVE", "ONENOTEM",
        "OUTLOOK", "MSPUB", "MSINFO", "MSACCESS", "GRAPH", "MSQRY32"
    )
    
    $stoppedProcesses = 0
    foreach ($process in $officeProcesses) {
        try {
            $runningProcesses = Get-Process -Name $process -ErrorAction SilentlyContinue
            if ($runningProcesses) {
                $runningProcesses | Stop-Process -Force -ErrorAction SilentlyContinue
                $stoppedProcesses++
                Write-Log "Stopped process: $process"
            }
        }
        catch {
            Write-Log "Process $process not running or already stopped" -Level "WARN"
        }
    }
    
    Write-Log "Stopped $stoppedProcesses Office processes"
}

# Function to remove Office components
function Remove-OfficeComponents {
    Write-Log "Removing Office components..."
    
    # Remove Office products using WMI
    $officeProducts = @(
        "*Microsoft 365*",
        "*Office 16*",
        "*Office 15*",
        "*Office 14*",
        "*Office 13*",
        "*Microsoft Office*",
        "*Access Database Engine*",
        "*Microsoft Access*"
    )
    
    $removedProducts = 0
    foreach ($pattern in $officeProducts) {
        try {
            $products = Get-WmiObject -Class Win32_Product | Where-Object {$_.Name -like $pattern}
            foreach ($product in $products) {
                Write-Log "Removing product: $($product.Name)"
                $result = $product.Uninstall()
                if ($result.ReturnValue -eq 0) {
                    $removedProducts++
                    Write-Log "Successfully removed: $($product.Name)"
                } else {
                    Write-Log "Failed to remove: $($product.Name) (Error: $($result.ReturnValue))" -Level "ERROR"
                }
            }
        }
        catch {
            Write-Log "Error processing pattern $pattern : $($_.Exception.Message)" -Level "ERROR"
        }
    }
    
    Write-Log "Removed $removedProducts Office products"
    
    # Remove registry entries
    $registryPaths = @(
        "HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall",
        "HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall"
    )
    
    $officePatterns = @(
        "*Microsoft 365*",
        "*Office 16*",
        "*Office 15*",
        "*Office 14*",
        "*Microsoft Office*",
        "*Access Database Engine*",
        "*Click-to-Run*"
    )
    
    $removedRegistryEntries = 0
    foreach ($path in $registryPaths) {
        if (Test-Path $path) {
            try {
                $items = Get-ChildItem -Path $path -ErrorAction SilentlyContinue
                foreach ($item in $items) {
                    $displayName = $item.GetValue("DisplayName")
                    if ($displayName) {
                        foreach ($pattern in $officePatterns) {
                            if ($displayName -like $pattern) {
                                Write-Log "Removing registry entry: $displayName"
                                try {
                                    Remove-Item -Path $item.PSPath -Recurse -Force -ErrorAction SilentlyContinue
                                    $removedRegistryEntries++
                                    Write-Log "Successfully removed registry entry: $displayName"
                                }
                                catch {
                                    Write-Log "Failed to remove registry entry $displayName : $($_.Exception.Message)" -Level "ERROR"
                                }
                                break
                            }
                        }
                    }
                }
            }
            catch {
                Write-Log "Error processing registry path $path : $($_.Exception.Message)" -Level "ERROR"
            }
        }
    }
    
    Write-Log "Removed $removedRegistryEntries registry entries"
    
    # Remove Click-to-Run components
    $clickToRunPaths = @(
        "$env:ProgramFiles\Microsoft Office",
        "$env:ProgramFiles(x86)\Microsoft Office",
        "$env:LocalAppData\Microsoft\Office",
        "$env:AppData\Microsoft\Office"
    )
    
    $removedFiles = 0
    foreach ($path in $clickToRunPaths) {
        if (Test-Path $path) {
            try {
                Write-Log "Removing Click-to-Run files from: $path"
                Remove-Item -Path $path -Recurse -Force -ErrorAction SilentlyContinue
                $removedFiles++
                Write-Log "Successfully removed Click-to-Run files from: $path"
            }
            catch {
                Write-Log "Failed to remove Click-to-Run files from $path : $($_.Exception.Message)" -Level "ERROR"
            }
        }
    }
    
    Write-Log "Removed Click-to-Run files from $removedFiles locations"
}

# Function to install ACE 16
function Install-ACE16 {
    Write-Log "Installing Microsoft Access Database Engine 2016..."
    
    $downloadUrl = "https://download.microsoft.com/download/3/5/C/35C84C36-661A-44E6-9324-8786B8DBE231/AccessDatabaseEngine_X64.exe"
    $installerPath = "$env:TEMP\AccessDatabaseEngine_X64.exe"
    
    try {
        # Download the installer
        Write-Log "Downloading ACE 16 installer..."
        Invoke-WebRequest -Uri $downloadUrl -OutFile $installerPath -UseBasicParsing
        
        if (Test-Path $installerPath) {
            Write-Log "Download completed: $installerPath"
            
            # Install silently
            Write-Log "Installing ACE 16 silently..."
            $process = Start-Process -FilePath $installerPath -ArgumentList "/quiet", "/norestart" -Wait -PassThru
            
            if ($process.ExitCode -eq 0) {
                Write-Log "ACE 16 installation completed successfully"
                
                # Clean up installer
                Remove-Item -Path $installerPath -Force -ErrorAction SilentlyContinue
                Write-Log "Cleaned up installer file"
                
                return $true
            } else {
                Write-Log "ACE 16 installation failed with exit code: $($process.ExitCode)" -Level "ERROR"
                return $false
            }
        } else {
            Write-Log "Failed to download ACE 16 installer" -Level "ERROR"
            return $false
        }
    }
    catch {
        Write-Log "Error during ACE 16 installation: $($_.Exception.Message)" -Level "ERROR"
        return $false
    }
}

# Function to verify ACE 16 installation
function Test-ACE16Installation {
    Write-Log "Verifying ACE 16 installation..."
    
    $verificationSteps = @{
        "Registry Check" = $false
        "Provider Check" = $false
        "DLL Check" = $false
    }
    
    # Check registry
    $registryPath = "HKLM:\SOFTWARE\Microsoft\Office\16.0\Access Connectivity Engine\Engines\ACE"
    if (Test-Path $registryPath) {
        $verificationSteps["Registry Check"] = $true
        Write-Log "Registry verification passed"
    } else {
        Write-Log "Registry verification failed" -Level "ERROR"
    }
    
    # Check OLE DB provider
    try {
        $providers = [System.Data.OleDb.OleDbEnumerator]::GetRootEnumerator()
        $aceProviderFound = $false
        while ($providers.Read()) {
            if ($providers["SOURCES_NAME"] -like "*ACE*") {
                $aceProviderFound = $true
                break
            }
        }
        if ($aceProviderFound) {
            $verificationSteps["Provider Check"] = $true
            Write-Log "OLE DB provider verification passed"
        } else {
            Write-Log "OLE DB provider verification failed" -Level "ERROR"
        }
    }
    catch {
        Write-Log "Error checking OLE DB providers: $($_.Exception.Message)" -Level "ERROR"
    }
    
    # Check DLL files
    $dllPaths = @(
        "$env:ProgramFiles\Common Files\Microsoft Shared\OFFICE16\ACEOLEDB.DLL",
        "$env:ProgramFiles\Common Files\Microsoft Shared\OFFICE16\ACECORE.DLL"
    )
    
    $dllFound = 0
    foreach ($dllPath in $dllPaths) {
        if (Test-Path $dllPath) {
            $dllFound++
            Write-Log "Found ACE DLL: $dllPath"
        }
    }
    
    if ($dllFound -eq $dllPaths.Count) {
        $verificationSteps["DLL Check"] = $true
        Write-Log "DLL verification passed"
    } else {
        Write-Log "DLL verification failed: Found $dllFound of $($dllPaths.Count) required DLLs" -Level "ERROR"
    }
    
    $passedSteps = $verificationSteps.Values | Where-Object { $_ -eq $true }
    if ($passedSteps.Count -eq $verificationSteps.Count) {
        Write-Log "ACE 16 installation verification completed successfully"
        return $true
    } else {
        Write-Log "ACE 16 installation verification failed" -Level "ERROR"
        return $false
    }
}

# Main execution
try {
    Write-Log "=== ACE 16 Automated Deployment Script Started ==="
    Write-Log "Script Version: 1.0"
    Write-Log "Target: Remove Office components and install ACE 16"
    Write-Log "Architecture: $Architecture"
    Write-Log "Log File: $LogFile"
    
    # Check administrator rights
    if (-not (Test-Administrator)) {
        Write-Log "ERROR: This script must be run as Administrator" -Level "ERROR"
        Write-Log "Please right-click PowerShell and select 'Run as Administrator'" -Level "ERROR"
        exit 1
    }
    
    # Check system requirements
    if (-not (Test-SystemRequirements)) {
        Write-Log "ERROR: System requirements not met. Check the log for details." -Level "ERROR"
        exit 1
    }
    
    # Create system restore point
    New-SystemRestorePoint
    
    # Stop Office processes
    Stop-OfficeProcesses
    
    # Remove Office components (unless skipped)
    if (-not $SkipOfficeRemoval) {
        Remove-OfficeComponents
    } else {
        Write-Log "Skipping Office component removal as requested"
    }
    
    # Install ACE 16 (unless skipped)
    if (-not $SkipACEInstall) {
        if (Install-ACE16) {
            if (Test-ACE16Installation) {
                Write-Log "=== ACE 16 Deployment Completed Successfully ==="
                
                if ($Restart) {
                    Write-Log "Restarting system in 30 seconds..." -Level "WARN"
                    Start-Sleep -Seconds 30
                    Restart-Computer -Force
                }
            } else {
                Write-Log "ACE 16 installation verification failed" -Level "ERROR"
                exit 1
            }
        } else {
            Write-Log "ACE 16 installation failed" -Level "ERROR"
            exit 1
        }
    } else {
        Write-Log "Skipping ACE 16 installation as requested"
    }
    
    Write-Log "=== Deployment script completed ==="
}
catch {
    Write-Log "Fatal error during deployment: $($_.Exception.Message)" -Level "ERROR"
    Write-Log "Stack trace: $($_.ScriptStackTrace)" -Level "ERROR"
    exit 1
} 