# Microsoft Access Database Engine 2016 Installation Script
# This script installs ACE 16 after Office components have been removed
# Run as Administrator

param(
    [switch]$Force,
    [switch]$Restart,
    [string]$LogFile = "ACE16Install.log",
    [string]$DownloadPath = "$env:TEMP\ACE16",
    [string]$Architecture = "x64"  # x64 or x86
)

# Function to write to log
function Write-Log {
    param([string]$Message, [string]$Level = "INFO", [switch]$Pause)
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $logMessage = "[$timestamp] [$Level] $Message"
    Write-Host $logMessage
    Add-Content -Path $LogFile -Value $logMessage
    
    if ($Pause) {
        Write-Host "Press any key to continue..." -ForegroundColor Yellow
        $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    }
}

# Function to check if running as administrator
function Test-Administrator {
    $currentUser = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($currentUser)
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

# Function to check if ACE 16 is already installed
function Test-ACE16Installed {
    Write-Log "Checking if ACE 16 is already installed..."
    
    $aceProviders = @(
        "Microsoft.ACE.OLEDB.16.0",
        "Microsoft.ACE.OLEDB.15.0",
        "Microsoft.ACE.OLEDB.14.0"
    )
    
    foreach ($provider in $aceProviders) {
        try {
            $testConnection = New-Object System.Data.OleDb.OleDbConnection("Provider=$provider;Data Source=test.accdb;")
            Write-Log "Found ACE provider: $provider"
            return $true
        }
        catch {
            Write-Log "Provider $provider not available: $($_.Exception.Message)" -Level "WARN"
        }
    }
    
    # Check registry for ACE installation
    $registryPaths = @(
        "HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall",
        "HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall"
    )
    
    foreach ($path in $registryPaths) {
        if (Test-Path $path) {
            $items = Get-ChildItem -Path $path -ErrorAction SilentlyContinue
            foreach ($item in $items) {
                $displayName = $item.GetValue("DisplayName")
                if ($displayName -and $displayName -like "*Access Database Engine*") {
                    Write-Log "Found ACE installation: $displayName"
                    return $true
                }
            }
        }
    }
    
    Write-Log "ACE 16 is not installed"
    return $false
}

# Function to download ACE 16 installer
function Download-ACE16 {
    Write-Log "Downloading ACE 16 installer..."
    
    # Create download directory
    if (-not (Test-Path $DownloadPath)) {
        New-Item -ItemType Directory -Path $DownloadPath -Force | Out-Null
        Write-Log "Created download directory: $DownloadPath"
    }
    
    # ACE 16 download URLs
    $downloadUrls = @{
        "x64" = "https://download.microsoft.com/download/3/5/C/35C84C36-661A-491E-A128-0B6E0E6B65F6/AccessDatabaseEngine_X64.exe"
        "x86" = "https://download.microsoft.com/download/3/5/C/35C84C36-661A-491E-A128-0B6E0E6B65F6/AccessDatabaseEngine.exe"
    }
    
    $url = $downloadUrls[$Architecture]
    $fileName = if ($Architecture -eq "x64") { "AccessDatabaseEngine_X64.exe" } else { "AccessDatabaseEngine.exe" }
    $filePath = Join-Path $DownloadPath $fileName
    
    try {
        Write-Log "Downloading from: $url"
        Write-Log "Saving to: $filePath"
        
        # Use WebClient for download with progress
        $webClient = New-Object System.Net.WebClient
        $webClient.DownloadFile($url, $filePath)
        
        if (Test-Path $filePath) {
            $fileSize = (Get-Item $filePath).Length
            Write-Log "Download completed. File size: $([math]::Round($fileSize / 1MB, 2)) MB"
            return $filePath
        } else {
            throw "Download failed - file not found"
        }
    }
    catch {
        Write-Log "Download failed: $($_.Exception.Message)" -Level "ERROR"
        return $null
    }
    finally {
        if ($webClient) {
            $webClient.Dispose()
        }
    }
}

# Function to install ACE 16
function Install-ACE16 {
    param([string]$InstallerPath)
    
    Write-Log "Installing ACE 16..."
    Write-Log "Installer path: $InstallerPath"
    
    try {
        # Installation parameters
        $arguments = @(
            "/quiet",
            "/passive",
            "/norestart",
            "/log",
            "$DownloadPath\ACE16_install.log"
        )
        
        Write-Log "Installation arguments: $($arguments -join ' ')"
        
        # Start installation process
        $process = Start-Process -FilePath $InstallerPath -ArgumentList $arguments -Wait -PassThru
        
        if ($process.ExitCode -eq 0) {
            Write-Log "ACE 16 installation completed successfully"
            return $true
        } else {
            Write-Log "ACE 16 installation failed with exit code: $($process.ExitCode)" -Level "ERROR"
            return $false
        }
    }
    catch {
        Write-Log "Installation error: $($_.Exception.Message)" -Level "ERROR"
        return $false
    }
}

# Function to verify ACE 16 installation
function Test-ACE16Verification {
    Write-Log "Verifying ACE 16 installation..."
    
    $verificationSteps = @()
    
    # Test 1: Check if ACE providers are available
    try {
        $testConnection = New-Object System.Data.OleDb.OleDbConnection("Provider=Microsoft.ACE.OLEDB.16.0;Data Source=test.accdb;")
        Write-Log "✓ ACE 16 OLEDB provider is available"
        $verificationSteps += "OLEDB Provider"
    }
    catch {
        Write-Log "✗ ACE 16 OLEDB provider not available: $($_.Exception.Message)" -Level "ERROR"
    }
    
    # Test 2: Check registry for ACE installation
    $registryPaths = @(
        "HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall",
        "HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall"
    )
    
    $aceFound = $false
    foreach ($path in $registryPaths) {
        if (Test-Path $path) {
            $items = Get-ChildItem -Path $path -ErrorAction SilentlyContinue
            foreach ($item in $items) {
                $displayName = $item.GetValue("DisplayName")
                if ($displayName -and $displayName -like "*Access Database Engine*") {
                    Write-Log "✓ Found ACE installation in registry: $displayName"
                    $aceFound = $true
                    $verificationSteps += "Registry Entry"
                    break
                }
            }
        }
        if ($aceFound) { break }
    }
    
    if (-not $aceFound) {
        Write-Log "✗ ACE installation not found in registry" -Level "ERROR"
    }
    
    # Test 3: Check for ACE DLL files
    $aceDllPaths = @(
        "C:\Windows\System32\ACEOLEDB16.DLL",
        "C:\Windows\SysWOW64\ACEOLEDB16.DLL"
    )
    
    foreach ($dllPath in $aceDllPaths) {
        if (Test-Path $dllPath) {
            Write-Log "✓ Found ACE DLL: $dllPath"
            $verificationSteps += "DLL Files"
            break
        }
    }
    
    if ($verificationSteps.Count -ge 2) {
        Write-Log "ACE 16 verification: SUCCESS - All critical components found"
        return $true
    } else {
        Write-Log "ACE 16 verification: FAILED - Missing critical components" -Level "ERROR"
        return $false
    }
}

# Function to create test database connection
function Test-DatabaseConnection {
    Write-Log "Testing database connection..."
    
    try {
        # Create a simple test connection string
        $connectionString = "Provider=Microsoft.ACE.OLEDB.16.0;Data Source=test.accdb;"
        
        # Test the connection
        $connection = New-Object System.Data.OleDb.OleDbConnection($connectionString)
        Write-Log "✓ Database connection test successful"
        return $true
    }
    catch {
        Write-Log "✗ Database connection test failed: $($_.Exception.Message)" -Level "ERROR"
        return $false
    }
    finally {
        if ($connection) {
            $connection.Dispose()
        }
    }
}

# Function to clean up installation files
function Clear-InstallationFiles {
    Write-Log "Cleaning up installation files..."
    
    try {
        if (Test-Path $DownloadPath) {
            Remove-Item -Path $DownloadPath -Recurse -Force -ErrorAction SilentlyContinue
            Write-Log "Cleaned up download directory: $DownloadPath"
        }
    }
    catch {
        Write-Log "Error cleaning up installation files: $($_.Exception.Message)" -Level "WARN"
    }
}

# Main execution
Write-Log "=== ACE 16 Installation Script Started ==="
Write-Log "Script Version: 1.0"
Write-Log "Target: Install Microsoft Access Database Engine 2016"
Write-Log "Architecture: $Architecture"
Write-Log "Log File: $LogFile"

# Check if running as administrator
if (-not (Test-Administrator)) {
    Write-Log "ERROR: This script must be run as Administrator" -Level "ERROR"
    Write-Log "Please right-click PowerShell and select 'Run as Administrator'"
    exit 1
}

# Check if ACE 16 is already installed
if (Test-ACE16Installed) {
    Write-Log "ACE 16 is already installed. Skipping installation."
    Write-Host "`nACE 16 is already installed on this system." -ForegroundColor Green
    exit 0
}

# Confirm before proceeding
if (-not $Force) {
    Write-Host "`nThis script will install Microsoft Access Database Engine 2016 ($Architecture-bit)." -ForegroundColor Yellow
    Write-Host "`nAre you sure you want to continue? (Y/N): " -ForegroundColor Cyan -NoNewline
    $confirmation = Read-Host
    if ($confirmation -ne "Y" -and $confirmation -ne "y") {
        Write-Log "Operation cancelled by user"
        exit 0
    }
}

try {
    # Download ACE 16 installer
    $installerPath = Download-ACE16
    if (-not $installerPath) {
        throw "Failed to download ACE 16 installer"
    }
    
    # Install ACE 16
    $installSuccess = Install-ACE16 -InstallerPath $installerPath
    if (-not $installSuccess) {
        throw "ACE 16 installation failed"
    }
    
    # Verify installation
    $verificationSuccess = Test-ACE16Verification
    if (-not $verificationSuccess) {
        throw "ACE 16 verification failed"
    }
    
    # Test database connection
    $connectionSuccess = Test-DatabaseConnection
    if (-not $connectionSuccess) {
        Write-Log "WARNING: Database connection test failed, but installation may still be functional" -Level "WARN"
    }
    
    # Clean up installation files
    Clear-InstallationFiles
    
    Write-Log "=== ACE 16 Installation Script Completed ===" -Pause
    Write-Log "SUCCESS: Microsoft Access Database Engine 2016 has been installed successfully" -Pause
    
    Write-Host "`nSUCCESS: Microsoft Access Database Engine 2016 has been installed successfully!" -ForegroundColor Green
    Write-Host "Your C# application should now be able to connect to Access databases." -ForegroundColor Green
    Write-Host "`nConnection string example:" -ForegroundColor Cyan
    Write-Host "Provider=Microsoft.ACE.OLEDB.16.0;Data Source=your_database.accdb;" -ForegroundColor White
    
    Write-Host "`nPress any key to exit..." -ForegroundColor Yellow
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    
    if ($Restart) {
        Write-Log "Restarting computer as requested..."
        Write-Host "`nRestarting computer in 10 seconds..." -ForegroundColor Cyan
        Start-Sleep -Seconds 10
        Restart-Computer -Force
    }
    
} catch {
    Write-Log "ERROR: An unexpected error occurred: $($_.Exception.Message)" -Level "ERROR"
    Write-Host "`nERROR: Installation failed. Check the log file: $LogFile" -ForegroundColor Red
    
    # Clean up on failure
    Clear-InstallationFiles
    
    exit 1
} 