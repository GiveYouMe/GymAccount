# ACE 16 Deployment Scripts

This collection of PowerShell scripts automates the removal of Microsoft Office components and installation of Microsoft Access Database Engine 2016 (ACE 16) for client deployment.

## Script Files

1. **Deploy-ACE16-Complete-Debug.ps1** - Main deployment script with optional pauses
2. **Deploy-ACE16-Auto-Release.ps1** - Automated deployment script (no pauses)
3. **Remove-OfficeComponents.ps1** - Office removal script
4. **Install-ACE16.ps1** - ACE 16 installation script
5. **Test-ACE16-Connection.ps1** - Test script to verify installation

## Prerequisites

- Windows 7 SP1 or later (Windows 10/11 recommended)
- PowerShell 5.0 or later
- Administrator privileges
- Internet connection for downloading ACE 16

## Quick Start

### For Interactive Deployment (with pauses)
```powershell
# Run as Administrator
.\1.Deploy-ACE16-Complete.ps1 -Force
```

### For Automated Deployment (no pauses)
```powershell
# Run as Administrator
.\2.Deploy-ACE16-Auto.ps1 -Force
```

### To skip pauses in interactive script
```powershell
# Run as Administrator
.\1.Deploy-ACE16-Complete.ps1 -Force -NoPause
```

## Script Parameters

### Common Parameters
- `-Force` - Skip confirmation prompts
- `-Restart` - Restart computer after successful installation
- `-SkipOfficeRemoval` - Skip Office component removal
- `-SkipACEInstall` - Skip ACE 16 installation
- `-LogFile` - Specify custom log file path (default: ACE16Deployment.log)
- `-Architecture` - Target architecture: x64 or x86 (default: x64)

### Interactive Script Only
- `-NoPause` - Disable pause points for automated execution

## Usage Examples

### Basic Deployment
```powershell
.\1.Deploy-ACE16-Complete.ps1 -Force
```

### Automated Deployment for Client Systems
```powershell
.\2.Deploy-ACE16-Auto.ps1 -Force -Restart
```

### Skip Office Removal (if already removed)
```powershell
.\1.Deploy-ACE16-Complete.ps1 -Force -SkipOfficeRemoval
```

### Install ACE 16 Only
```powershell
.\1.Deploy-ACE16-Complete.ps1 -Force -SkipOfficeRemoval -SkipACEInstall:$false
```

### Custom Log File
```powershell
.\1.Deploy-ACE16-Complete.ps1 -Force -LogFile "C:\Logs\ACE16_Install.log"
```

## Setup Instructions

### 1. Enable PowerShell Execution Policy
```powershell
# For current user only (recommended)
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser

# For all users (requires admin)
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope LocalMachine
```

### 2. Run PowerShell as Administrator
- Right-click PowerShell
- Select "Run as Administrator"

### 3. Navigate to Script Directory
```powershell
cd "D:\Projects\EMCT\GymAccount.NET\GymAccount\ACE16"
```

### 4. Execute Script
```powershell
.\1.Deploy-ACE16-Complete.ps1 -Force
```

## What the Scripts Do

### Office Component Removal
- Stops all Office processes
- Uninstalls Office products via WMI
- Removes registry entries
- Cleans up Click-to-Run components
- Removes Office files from common locations

### ACE 16 Installation
- Downloads Microsoft Access Database Engine 2016
- Installs silently with no user interaction
- Verifies installation through multiple checks
- Cleans up installation files

### Verification Steps
- Registry key verification
- OLE DB provider verification
- DLL file verification
- Database connectivity test

## Troubleshooting

### Common Issues

#### "Execution Policy Error"
```powershell
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
```

#### "Administrator Rights Required"
- Right-click PowerShell and select "Run as Administrator"

#### "Windows Version Not Supported"
- Script supports Windows 7 SP1 and later
- Check Windows version: `winver`

#### "Internet Connection Required"
- Ensure internet access for downloading ACE 16
- Check firewall/proxy settings

#### "Installation Failed"
- Check log file for detailed error messages
- Ensure no Office applications are running
- Try running with `-SkipOfficeRemoval` if Office is already removed

### Log Files
- Default log: `ACE16Deployment.log` in script directory
- Custom log: Specify with `-LogFile` parameter
- Log includes timestamps, error levels, and detailed messages

### Manual Verification
```powershell
# Test ACE 16 installation
.\Test-ACE16-Connection.ps1

# Check registry
Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Office\16.0\Access Connectivity Engine\Engines\ACE"

# Check DLL files
Test-Path "$env:ProgramFiles\Common Files\Microsoft Shared\OFFICE16\ACEOLEDB.DLL"
```

## Deployment Scenarios

### Client Deployment (Automated)
```powershell
.\2.Deploy-ACE16-Auto.ps1 -Force -Restart
```

### Development Environment
```powershell
.\1.Deploy-ACE16-Complete.ps1 -Force -NoPause
```

### Troubleshooting Installation
```powershell
.\1.Deploy-ACE16-Complete.ps1 -Force -SkipOfficeRemoval
```

### Testing Only
```powershell
.\Test-ACE16-Connection.ps1
```

## Safety Features

- System restore point creation
- Comprehensive logging
- Error handling and rollback
- Process verification
- Multiple verification steps

## Support

For issues or questions:
1. Check the log file for detailed error messages
2. Verify system requirements
3. Ensure administrator privileges
4. Test with individual scripts if needed

## Version History

- v1.0 - Initial release with interactive and automated versions
- Added Windows 11 support
- Added NoPause parameter for interactive script
- Improved error handling and logging 