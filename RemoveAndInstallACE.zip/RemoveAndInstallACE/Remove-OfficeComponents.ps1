# Office Components Removal Script for ACE 16 Deployment
# This script removes all Office components to prepare for Microsoft Access Database Engine 2016 installation
# Run as Administrator

param(
    [switch]$Force,
    [switch]$Restart,
    [string]$LogFile = "OfficeRemoval.log"
)

# Function to write to log
function Write-Log {
    param([string]$Message, [string]$Level = "INFO", [switch]$Pause)
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $logMessage = "[$timestamp] [$Level] $Message"
    Write-Host $logMessage
    Add-Content -Path $LogFile -Value $logMessage
    
    if ($Pause) {
        Write-Host "Press any key to continue..." -ForegroundColor Yellow
        $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    }
}

# Function to check if running as administrator
function Test-Administrator {
    $currentUser = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($currentUser)
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

# Function to stop Office processes
function Stop-OfficeProcesses {
    Write-Log "Stopping Office processes..."
    $officeProcesses = @(
        "WINWORD", "EXCEL", "POWERPNT", "OUTLOOK", "MSACCESS", "ONENOTE",
        "WINPROJ", "VISIO", "LYNC", "TEAMS", "ONEDRIVE", "ONENOTEM",
        "OUTLOOK", "MSPUB", "MSINFO", "MSACCESS", "GRAPH", "MSQRY32"
    )
    
    foreach ($process in $officeProcesses) {
        try {
            Get-Process -Name $process -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
            Write-Log "Stopped process: $process"
        }
        catch {
            Write-Log "Process $process not running or already stopped" -Level "WARN"
        }
    }
}

# Function to remove Office products using WMI
function Remove-OfficeProducts {
    Write-Log "Removing Office products using WMI..."
    
    $officeProducts = @(
        "*Microsoft 365*",
        "*Office 16*",
        "*Office 15*",
        "*Office 14*",
        "*Office 13*",
        "*Microsoft Office*",
        "*Access Database Engine*",
        "*Microsoft Access*"
    )
    
    foreach ($pattern in $officeProducts) {
        try {
            $products = Get-WmiObject -Class Win32_Product | Where-Object {$_.Name -like $pattern}
            foreach ($product in $products) {
                Write-Log "Removing product: $($product.Name)"
                $result = $product.Uninstall()
                if ($result.ReturnValue -eq 0) {
                    Write-Log "Successfully removed: $($product.Name)"
                } else {
                    Write-Log "Failed to remove: $($product.Name) (Error: $($result.ReturnValue))" -Level "ERROR"
                }
            }
        }
        catch {
            Write-Log "Error processing pattern $pattern : $($_.Exception.Message)" -Level "ERROR"
        }
    }
}

# Function to remove Office registry entries
function Remove-OfficeRegistry {
    Write-Log "Removing Office registry entries..."
    
    $registryPaths = @(
        "HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall",
        "HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall",
        "HKLM:\Software\Microsoft\Office",
        "HKLM:\Software\WOW6432Node\Microsoft\Office",
        "HKLM:\Software\Microsoft\Office16",
        "HKLM:\Software\WOW6432Node\Microsoft\Office16",
        "HKLM:\Software\Microsoft\Office15",
        "HKLM:\Software\WOW6432Node\Microsoft\Office15",
        "HKLM:\Software\Microsoft\Office14",
        "HKLM:\Software\WOW6432Node\Microsoft\Office14"
    )
    
    $officePatterns = @(
        "*Microsoft 365*",
        "*Office 16*",
        "*Office 15*",
        "*Office 14*",
        "*Microsoft Office*",
        "*Access Database Engine*",
        "*Click-to-Run*",
        "*Office16*",
        "*Office15*",
        "*Office14*"
    )
    
    foreach ($path in $registryPaths) {
        if (Test-Path $path) {
            try {
                $items = Get-ChildItem -Path $path -ErrorAction SilentlyContinue
                foreach ($item in $items) {
                    $displayName = $item.GetValue("DisplayName")
                    if ($displayName) {
                        foreach ($pattern in $officePatterns) {
                            if ($displayName -like $pattern) {
                                Write-Log "Removing registry entry: $displayName"
                                try {
                                    Remove-Item -Path $item.PSPath -Recurse -Force -ErrorAction SilentlyContinue
                                    Write-Log "Successfully removed registry entry: $displayName"
                                }
                                catch {
                                    Write-Log "Failed to remove registry entry $displayName : $($_.Exception.Message)" -Level "ERROR"
                                }
                                break
                            }
                        }
                    }
                }
            }
            catch {
                Write-Log "Error processing registry path $path : $($_.Exception.Message)" -Level "ERROR"
            }
        }
    }
}

# Function to remove Office files and folders
function Remove-OfficeFiles {
    Write-Log "Removing Office files and folders..."
    
    $officePaths = @(
        "C:\Program Files\Microsoft Office",
        "C:\Program Files (x86)\Microsoft Office",
        "C:\Program Files\Common Files\Microsoft Shared\Office16",
        "C:\Program Files (x86)\Common Files\Microsoft Shared\Office16",
        "C:\Program Files\Common Files\Microsoft Shared\Office15",
        "C:\Program Files (x86)\Common Files\Microsoft Shared\Office15",
        "C:\Program Files\Common Files\Microsoft Shared\Office14",
        "C:\Program Files (x86)\Common Files\Microsoft Shared\Office14",
        "C:\Program Files\Microsoft Office\Office16",
        "C:\Program Files (x86)\Microsoft Office\Office16",
        "C:\Program Files\Microsoft Office\Office15",
        "C:\Program Files (x86)\Microsoft Office\Office15",
        "C:\Program Files\Microsoft Office\Office14",
        "C:\Program Files (x86)\Microsoft Office\Office14"
    )
    
    foreach ($path in $officePaths) {
        if (Test-Path $path) {
            try {
                Write-Log "Removing directory: $path"
                Remove-Item -Path $path -Recurse -Force -ErrorAction SilentlyContinue
                Write-Log "Successfully removed directory: $path"
            }
            catch {
                Write-Log "Failed to remove directory $path : $($_.Exception.Message)" -Level "ERROR"
            }
        }
    }
}

# Function to remove Click-to-Run components
function Remove-ClickToRunComponents {
    Write-Log "Removing Click-to-Run components..."
    
    $clickToRunPath = "C:\Program Files\Common Files\Microsoft Shared\ClickToRun"
    if (Test-Path $clickToRunPath) {
        try {
            # Stop Click-to-Run service
            $service = Get-Service -Name "ClickToRunSvc" -ErrorAction SilentlyContinue
            if ($service) {
                Stop-Service -Name "ClickToRunSvc" -Force -ErrorAction SilentlyContinue
                Set-Service -Name "ClickToRunSvc" -StartupType Disabled -ErrorAction SilentlyContinue
                Write-Log "Stopped and disabled Click-to-Run service"
            }
            
            # Remove Click-to-Run directory
            Remove-Item -Path $clickToRunPath -Recurse -Force -ErrorAction SilentlyContinue
            Write-Log "Removed Click-to-Run directory"
        }
        catch {
            Write-Log "Error removing Click-to-Run components: $($_.Exception.Message)" -Level "ERROR"
        }
    }
}

# Function to clean up temporary files
function Clear-OfficeTempFiles {
    Write-Log "Cleaning up Office temporary files..."
    
    $tempPaths = @(
        "$env:TEMP\*Office*",
        "$env:TEMP\*Excel*",
        "$env:TEMP\*Word*",
        "$env:TEMP\*PowerPoint*",
        "$env:TEMP\*Outlook*",
        "$env:TEMP\*Access*",
        "$env:TEMP\*OneNote*",
        "$env:LOCALAPPDATA\Microsoft\Office\*",
        "$env:LOCALAPPDATA\Microsoft\Office16\*",
        "$env:LOCALAPPDATA\Microsoft\Office15\*",
        "$env:LOCALAPPDATA\Microsoft\Office14\*"
    )
    
    foreach ($path in $tempPaths) {
        try {
            if (Test-Path $path) {
                Remove-Item -Path $path -Recurse -Force -ErrorAction SilentlyContinue
                Write-Log "Cleaned up: $path"
            }
        }
        catch {
            Write-Log "Error cleaning up $path : $($_.Exception.Message)" -Level "ERROR"
        }
    }
}

# Function to verify removal
function Test-OfficeRemoval {
    Write-Log "Verifying Office removal..."
    
    $remainingProducts = @()
    
    # Check for remaining Office products
    $officeProducts = Get-WmiObject -Class Win32_Product | Where-Object {
        $_.Name -like "*Microsoft 365*" -or 
        $_.Name -like "*Office 16*" -or 
        $_.Name -like "*Office 15*" -or 
        $_.Name -like "*Office 14*" -or
        $_.Name -like "*Microsoft Office*"
    }
    
    if ($officeProducts) {
        foreach ($product in $officeProducts) {
            $remainingProducts += $product.Name
        }
    }
    
    # Check for remaining registry entries
    $registryPaths = @(
        "HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall",
        "HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall"
    )
    
    foreach ($path in $registryPaths) {
        if (Test-Path $path) {
            $items = Get-ChildItem -Path $path -ErrorAction SilentlyContinue
            foreach ($item in $items) {
                $displayName = $item.GetValue("DisplayName")
                if ($displayName -and ($displayName -like "*Microsoft 365*" -or $displayName -like "*Office 16*" -or $displayName -like "*Office 15*" -or $displayName -like "*Office 14*")) {
                    $remainingProducts += $displayName
                }
            }
        }
    }
    
    if ($remainingProducts.Count -eq 0) {
        Write-Log "Office removal verification: SUCCESS - No Office components found"
        return $true
    } else {
        Write-Log "Office removal verification: WARNING - Found remaining components:" -Level "WARN"
        foreach ($product in $remainingProducts) {
            Write-Log "  - $product" -Level "WARN"
        }
        return $false
    }
}

# Main execution
Write-Log "=== Office Components Removal Script Started ==="
Write-Log "Script Version: 1.0"
Write-Log "Target: Remove all Office components for ACE 16 deployment"
Write-Log "Log File: $LogFile"

# Check if running as administrator
if (-not (Test-Administrator)) {
    Write-Log "ERROR: This script must be run as Administrator" -Level "ERROR"
    Write-Log "Please right-click PowerShell and select 'Run as Administrator'"
    exit 1
}

# Confirm before proceeding
if (-not $Force) {
    Write-Host "`nWARNING: This script will remove ALL Office components from your system." -ForegroundColor Yellow
    Write-Host "This includes Microsoft 365 Apps, Office 2016/2019/2021, and related components." -ForegroundColor Yellow
    Write-Host "`nAre you sure you want to continue? (Y/N): " -ForegroundColor Red -NoNewline
    $confirmation = Read-Host
    if ($confirmation -ne "Y" -and $confirmation -ne "y") {
        Write-Log "Operation cancelled by user"
        exit 0
    }
}

try {
    # Stop Office processes
    Stop-OfficeProcesses
    
    # Remove Office products
    Remove-OfficeProducts
    
    # Remove registry entries
    Remove-OfficeRegistry
    
    # Remove Click-to-Run components
    Remove-ClickToRunComponents
    
    # Remove Office files
    Remove-OfficeFiles
    
    # Clean up temporary files
    Clear-OfficeTempFiles
    
    # Verify removal
    $removalSuccess = Test-OfficeRemoval
    
    Write-Log "=== Office Components Removal Script Completed ===" -Pause
    
    if ($removalSuccess) {
        Write-Log "SUCCESS: All Office components have been removed successfully" -Pause
        Write-Host "`nSUCCESS: All Office components have been removed successfully!" -ForegroundColor Green
        Write-Host "You can now install Microsoft Access Database Engine 2016." -ForegroundColor Green
    } else {
        Write-Log "WARNING: Some Office components may still remain" -Pause
        Write-Host "`nWARNING: Some Office components may still remain." -ForegroundColor Yellow
        Write-Host "Check the log file for details: $LogFile" -ForegroundColor Yellow
    }
    
    Write-Host "`nPress any key to exit..." -ForegroundColor Yellow
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    
    if ($Restart) {
        Write-Log "Restarting computer as requested..."
        Write-Host "`nRestarting computer in 10 seconds..." -ForegroundColor Cyan
        Start-Sleep -Seconds 10
        Restart-Computer -Force
    }
    
} catch {
    Write-Log "ERROR: An unexpected error occurred: $($_.Exception.Message)" -Level "ERROR"
    Write-Host "`nERROR: An unexpected error occurred. Check the log file: $LogFile" -ForegroundColor Red
    exit 1
} 